# Import
from .license_plate import LicensePlateDetector