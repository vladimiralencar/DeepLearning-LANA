# Imports
import numpy as np
import cv2

class BlockBinaryPixelSum:
	def __init__(self, targetSize=(30, 15), blockSizes=((5, 5),)):
		# Armazena o tamanho do alvo da imagem a ser descrita juntamente com o conjunto de tamanhos de bloco
		self.targetSize = targetSize
		self.blockSizes = blockSizes

	def describe(self, image):
		# Redimensiona a imagem para o tamanho do alvo e inicializa o vetor de características
		image = cv2.resize(image, (self.targetSize[1], self.targetSize[0]))
		features = []

		# Loop sobre os tamanhos dos blocos
		for (blockW, blockH) in self.blockSizes:
			# Loop sobre a imagem para o tamanho atual do bloco
			for y in range(0, image.shape[0], blockH):
				for x in range(0, image.shape[1], blockW):
					# Extrai o ROI atual, conta o número total de pixels não-zero no ROI, normalizando pelo tamanho total do bloco
					roi = image[y:y + blockH, x:x + blockW]
					total = cv2.countNonZero(roi) / float(roi.shape[0] * roi.shape[1])

					# Atualiza o vetor de características
					features.append(total)

		# Retorna os recursos
		return np.array(features)